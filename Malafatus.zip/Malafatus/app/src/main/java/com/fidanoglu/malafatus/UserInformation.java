package com.fidanoglu.malafatus;

public class UserInformation {
    public String firstName;
    public String surname;
    public String dateOfBirth;

    public UserInformation() {}
    public UserInformation(String name, String surname, String dateOfBirth) {
        this.firstName = name;
        this.surname = surname;
        this.dateOfBirth = dateOfBirth;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getSurname() {
        return surname;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }
}
